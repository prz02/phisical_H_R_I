#ifndef ADMITTANCE_H
#define ADMITTANCE_H

#include <utility/filters/AnalogFilter.hpp>
#include <forecast/Controller.hpp>

namespace controllers
{

    class AdmittanceControl : public forecast::Controller
    {
    public:
        AdmittanceControl(float kd = 0, float bd = 0);
        virtual float process(const forecast::IHardware *hw, std::vector<float> ref) override;

    protected:
        
        // === Admittance parameters and variables === 
        float bd = 0.0f;
        float kd = 0.0f;
        std::shared_ptr<utility::AnalogFilter> admittance_block;

        // === Force loop variables === 
        float adm_out = 0.0;
        float tau_e = 0.0f;
        float tau_d = 0.0f;
        float tau_err = 0.0f;

        // === Position-current parameters === 
        float theta_eq = 0.0f;
        float pos_err = 0.0f;
        float theta = 0.0f;
        float dt = 0.0f;
        float derr_poscur = 0.0f;
        float err_poscur_prev = 0.0f;
        float i_ref_poscur = 0.0f;
        float out_poscur = 0.0f;
        float kp_pos_cur = 0.0f;
        float kd_pos_cur = 0.0f;
        // === Filter variables for FF === 
        float fc = 0.0f;
        float tau = 0.0f;
        float alpha = 0.0f;
        float adm_out_dot_raw = 0.0f;
        float adm_out_past = 0.0f;
        float adm_out_dot = 0.0f;
        float adm_out_dotdot_raw = 0.0f;
        float adm_out_dotdot = 0.0f;
        float adm_out_dot_past = 0.0f;
        float adm_out_dotdot_past = 0.0f;
        float B = 0.0068;
        float J = 0.0104;

    };

    inline forecast::ControllerFactory::Builder make_admittance_controller_builder()
    {

        auto fn = [](std::vector<float> params) -> forecast::Controller *
        {
            return new AdmittanceControl(params[0], params[1]);
        };

        return {fn, {"kd", "bd"}, {"theta_eq"}};
    }

}

#endif

