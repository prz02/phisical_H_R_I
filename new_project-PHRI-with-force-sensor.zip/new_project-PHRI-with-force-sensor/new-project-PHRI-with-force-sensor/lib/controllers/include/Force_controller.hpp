#ifndef FORCE_CONTROLLER_H
#define FORCE_CONTROLLER_H

#include <forecast/Controller.hpp>

namespace controllers
{
    class Force_controller : public forecast::Controller
    {
    public:
        Force_controller(float kp_force = 0.0f);
        virtual float process(const forecast::IHardware *hw, std::vector<float> ref) override;

    protected:
        
        // === Force loop variable === 
        float kp_force = 0.0f;
        float tau_e = 0.0f;
        float tau_m = 0.0f;

        // === Other variables ===
        float reference = 0.0f;
        
    };

    inline forecast::ControllerFactory::Builder make_force_controller_builder()
    {
        auto fn = [](std::vector<float> params) -> forecast::Controller *
        {
            if (params.size() < 1)
                return nullptr;

            return new Force_controller(params[0]);
        };

        return {fn, {"kp_foce"}, {"Reference", "Output"}};
    }

}

#endif
