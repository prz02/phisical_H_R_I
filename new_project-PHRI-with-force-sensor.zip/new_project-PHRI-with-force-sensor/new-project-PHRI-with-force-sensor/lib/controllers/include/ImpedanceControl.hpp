#ifndef IMPEDEDANCE_H
#define IMPEDEDANCE_H

#include <utility/filters/AnalogFilter.hpp>
#include <forecast/Controller.hpp>

namespace controllers
{

    class ImpedanceControl : public forecast::Controller
    {
    public:
        ImpedanceControl(float kd = 0, float bd = 0, float kpf = 0);
        virtual float process(const forecast::IHardware *hw, std::vector<float> ref) override;

    protected:
        
        // === Impedence parameters ===
        float bd = 0.0f;
        float kd = 0.0f;

        // === Force loop parameter ===
        float kpf = 0.0f;

        // === Other variables === 
        float reference = 0.0f;
        float out;

    };

    inline forecast::ControllerFactory::Builder make_impedence_controller_builder()
    {

        auto fn = [](std::vector<float> params) -> forecast::Controller *
        {
            return new ImpedanceControl(params[0], params[1], params[2]);
        };

        return {fn, {"kd", "bd", "kpf"}, {"Reference"}};
    }

}

#endif

