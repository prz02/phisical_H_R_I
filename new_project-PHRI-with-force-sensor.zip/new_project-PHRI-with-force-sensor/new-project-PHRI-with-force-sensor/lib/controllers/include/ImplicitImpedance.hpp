#ifndef IMP_H
#define IMP_H

#include <utility/filters/AnalogFilter.hpp>
#include <forecast/Controller.hpp>

namespace controllers

{

    class ImplicitImpedance : public forecast::Controller
    {
    public:
        ImplicitImpedance(float kd = 0, float bd = 0);
        virtual float process(const forecast::IHardware *hw, std::vector<float> ref) override;

    protected:

        // === Impedence parameters ===
        float kd = 0.0f;
        float bd = 0.0f;

        // === Implicit impedence loop variables ===
        float u_pos = 0.0f;
        float u_vel = 0.0f;

        // === Other variables ===
        float out = 0.0f;
        float reference = 0.0f;

    };

    inline forecast::ControllerFactory::Builder make_imp_impedence_controller_builder()
    {

        auto fn = [](std::vector<float> params) -> forecast::Controller *
        {
            return new ImplicitImpedance(params[0], params[1]);
        };

        return {fn, {"kd", "bd"}, {"Reference"}};
    }

}

#endif

