#ifndef POSITION_PID_H
#define POSITION_PID_H

#include <forecast/Controller.hpp>
#include <utility/filters/AnalogFilter.hpp>
template<typename T>
T clamp(const T& val, const T& min_val, const T& max_val) {
    if (val < min_val) return min_val;
    else if (val > max_val) return max_val;
    else return val;
}
namespace controllers
{
    class PositionPID : public forecast::Controller
    {
    public:
        PositionPID(float kp = 0.0f, float ki = 0.0f, float kd = 0.0f);
        virtual float process(const forecast::IHardware *hw, std::vector<float> ref) override;

    protected:
        float kp = 0.0f;
        float ki = 0.0f;
        float kd = 0.0f;

        float theta = 0.0f;
        float dt = 0.0f;
        float err = 0.0f;
        float derr = 0.0f;
        float ierr = 0.0f;
        float errPast = 0.0f;

        float out;
        float reference = 0.0;
        
        // Controllers of position_current feedback
        std::shared_ptr<utility::AnalogFilter> controller_pos_cur; // questo è l'oggetto per implmentare la TF
        
        // Controllers of position, velocity, current feedback
        // variabili globali
        float fc = 0.0;
        float tau = 0.0;
        float alpha = 0.0;
        float theta_dot_raw = 0.0;
        float theta_dot = 0.0;
        float theta_dotdot_raw = 0.0;
        float theta_dotdot = 0.0;
        float pos_err = 0.0;
        float B = 0.0068;
        float J = 0.0104;
        float theta_past = 0.0;
        float theta_dot_past = 0.0;
        float theta_dotdot_past = 0.0;

        //variabili pos_cur
        float kp_pos_cur = 0.0;
        float kd_pos_cur = 0.0;
        float err_poscur_prev = 0.0;
        float derr_poscur = 0.0;
        float i_ref_poscur = 0.0;
        float out_poscur = 0.0;
        
        //variabili pos_vel_cur
        float kp_pos = 0.0;
        float kp_position;
        float kd_position;
        float omega;
        float derr_posvel = 0.0;
        float err_posvel_prev = 0.0;
        float derr_posvel_prev = 0.0;
        float v_ref = 0.0;
        float v_meas = 0.0;
        float v_err = 0.0;
         float i_ref = 0.0;
         float v_err_prev = 0.0;

        std::shared_ptr<utility::AnalogFilter> low_pass_filter;  //cerchiamo di pulire la velocità dato che non abbiamo il riduttore 
        std::shared_ptr<utility::AnalogFilter> theta_dot_filter;
        std::shared_ptr<utility::AnalogFilter> theta_dotdot_filter;
        std::shared_ptr<utility::AnalogFilter> controller_pos_vel_cur_velocity; 
    };

    inline forecast::ControllerFactory::Builder make_position_PID_builder()
    {
        auto fn = [](std::vector<float> params) -> forecast::Controller *
        {
            if (params.size() < 3)
                return nullptr;

            return new PositionPID(params[0], params[1], params[2]);
        };

        return {fn, {"KP", "KI", "KD"}, {"Reference", "Output"}};
    }
    
}

#endif

