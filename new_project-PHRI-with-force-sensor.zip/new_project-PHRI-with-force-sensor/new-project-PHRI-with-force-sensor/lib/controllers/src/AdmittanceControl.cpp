#include <AdmittanceControl.hpp>

using namespace controllers;



AdmittanceControl::AdmittanceControl(float bd, float kd)
    : bd(bd),
      kd(kd)
{
    logs.push_back(&theta_eq);
    logs.push_back(&out_poscur);
    kp_pos_cur = 114.841373;
    kd_pos_cur = 8.7067;

    double num_admittance[2] = {0, 1}; 
    double den_admittance[2] = {bd, kd};
    admittance_block = std::make_shared<utility::AnalogFilter>(1, den_admittance, num_admittance);
}

float AdmittanceControl::process(const forecast::IHardware *hw, std::vector<float> ref)
{
    theta_eq = ref[0];
    
    theta = hw->get_theta(0);
    dt = hw->get_dt();

    tau_e = hw->get_tau_s(0);
  
    tau_d = 0;

    tau_err = tau_d-tau_e;

    // === Admittance implementation ===
    adm_out = admittance_block->process(tau_err,dt); 

    // === Input for position loop ===
    pos_err = adm_out + theta_eq - theta; 
    
    // === Filtering of the derivatives ===
    // Filter parameters
    // fc = 2.0f;
    // tau = 1.0f / (2.0f * M_PI * fc);
    // alpha = dt / (tau + dt);

    // Filtering of the first derivative
    // adm_out_dot_raw = (adm_out - adm_out_past) / dt;
    // adm_out_dot = alpha * adm_out_dot_raw + (1.0f - alpha) * adm_out_dot_past;

    // Filtering of the second derivative
    // adm_out_dotdot_raw = (adm_out_dot - adm_out_dot_past) / dt;
    // adm_out_dotdot = alpha * adm_out_dotdot_raw + (1.0f - alpha) * adm_out_dotdot_past;

    // === PD controller ===
    derr_poscur = (pos_err - err_poscur_prev) / dt;
    err_poscur_prev = pos_err;

    // Anti-windup
    if (fabs(out_poscur) > 2.26f && (pos_err * out_poscur) >= 0.0f) {
        pos_err = 0.0f;
    }

    i_ref_poscur = kp_pos_cur * pos_err + kd_pos_cur * derr_poscur;
    out_poscur = i_ref_poscur;//+ adm_out_dotdot * J + adm_out_dot * B;
    
    // === Update of the values ===
    // adm_out_past = adm_out;
    // adm_out_dot_past = adm_out_dot;
    // adm_out_dotdot_past = adm_out_dotdot;

    return out_poscur; 
}
