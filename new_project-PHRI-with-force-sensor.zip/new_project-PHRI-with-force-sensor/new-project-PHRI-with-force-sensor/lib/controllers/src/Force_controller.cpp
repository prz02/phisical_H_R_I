#include <Force_controller.hpp>

using namespace controllers;

Force_controller::Force_controller(float kp_force)
    : kp_force(kp_force)
{
    logs.push_back(&reference);
}

float Force_controller::process(const forecast::IHardware *hw, std::vector<float> ref)
{
    reference = ref[0];

    // === Force loop === 
    tau_e = hw->get_tau_s(0);
    tau_m = -kp_force*tau_e;
    
    return tau_m;
}
