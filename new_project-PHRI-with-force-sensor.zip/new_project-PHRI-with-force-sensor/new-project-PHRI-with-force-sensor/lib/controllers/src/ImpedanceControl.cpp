#include <ImpedanceControl.hpp>

using namespace controllers;



ImpedanceControl::ImpedanceControl(float kd, float bd, float kpf)
    : bd(bd),
      kd(kd),
      kpf(kpf)
{
    logs.push_back(&reference);
    logs.push_back(&out);
}

float ImpedanceControl::process(const forecast::IHardware *hw, std::vector<float> ref)
{
    reference = ref[0];
    
    // === Getting the data ===
    float tau_e = hw->get_tau_s(0);
    float pos_err = reference - hw->get_theta(0);
    float vel = hw->get_d_theta(0);

    // === Impedence implemetation ===
    float tau_intermedio = pos_err*kd +(-vel)*bd; // tau_intemedio = pos_err*kd + (v_ref-vel)*bd, but v_ref is none so only -vel
    
    // === Force loop ===
    out= (tau_intermedio - tau_e)*kpf + tau_intermedio;

    return out; 
}
