#include <ImplicitImpedance.hpp>

using namespace controllers;

ImplicitImpedance::ImplicitImpedance(float kd, float bd)
    :kd(kd), bd(bd)
{
    logs.push_back(&reference);
    logs.push_back(&out);
}


float ImplicitImpedance::process(const forecast::IHardware *hw, std::vector<float> ref)
{
    reference = ref[0];
    u_pos = -kd * (hw->get_theta(0) - reference);
    u_vel = -bd * (hw->get_d_theta(0));
    out = u_pos + u_vel;  
    return out; 
}
