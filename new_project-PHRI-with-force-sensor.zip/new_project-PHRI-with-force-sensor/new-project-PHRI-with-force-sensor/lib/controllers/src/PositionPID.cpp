#include <PositionPID.hpp>
#include <cmath>
using namespace controllers;

PositionPID::PositionPID(float kp, float ki, float kd)
    : kp(kp), ki(ki), kd(kd), err(0.f), derr(0.f), ierr(0.f), errPast(0.f)
{
    logs.push_back(&reference);
    logs.push_back(&out);

    // From sisotool => C
    // int order = 1;
    // double num[order_of_the_TF + 1]

    // Controller of position, current feedback
    double num_pos_cur[2] = {170.18, 1025.67}; // dall'ordine maggio a quello minoe e metto i coefs, se non ho il coef metto 0
    double den_pos_cur[2] = {1.0, 0};
    controller_pos_cur = std::make_shared<utility::AnalogFilter>(1, den_pos_cur, num_pos_cur);
    kp_pos_cur = 114.841373;
    kd_pos_cur = 8.7067;

    // Controllers of position, velocity, current feedback
    // Position controller
    kp_pos = 90; //40
    kp_position = 73.124293;
    kd_position = 0.039083;

    // Low pass filter
    // omega = 2*M_PI*10; //filtro che a 10Hz mi taglia
    // double num_filter[2] = {0, omega}; 
    // double den_filter[2] = {1.0, omega};
    // low_pass_filter = std::make_shared<utility::AnalogFilter>(1, den_filter, num_filter);
    // double omega = 2 * M_PI * 20.0;  // ad esempio: taglio a 20 Hz
    // double num[2] = {0, omega};
    // double den[2] = {1.0, omega};
    // theta_dot_filter = std::make_shared<utility::AnalogFilter>(1, den, num);

    // Velocity controller
    double num_pos_vel_cur[2] = {12.956, 569.42}; 
    double den_pos_vel_cur[2] = {1.0, 0};
    controller_pos_vel_cur_velocity = std::make_shared<utility::AnalogFilter>(1, den_pos_vel_cur, num_pos_vel_cur);

}

float PositionPID::process(const forecast::IHardware *hw, std::vector<float> ref)
{
    // === Letture iniziali ===
    theta = hw->get_theta(0);
    reference = ref[0];
    dt = hw->get_dt();
    if (dt <= 0.0f) return 0.0f;

    // === Parametri del filtro passa basso (frequenza taglio 5 Hz) ===
    fc = 1.0f;
    tau = 1.0f / (2.0f * M_PI * fc);
    alpha = dt / (tau + dt);

    // === Calcolo derivate con filtraggio ===
    theta_dot_raw = (reference - theta_past) / dt;
    theta_dot = alpha * theta_dot_raw + (1.0f - alpha) * theta_dot_past;

    theta_dotdot_raw = (theta_dot - theta_dot_past) / dt;
    theta_dotdot = alpha * theta_dotdot_raw + (1.0f - alpha) * theta_dotdot_past;

    // === Errore di posizione ===
    pos_err = reference - theta;

    //=== Controllo posizione → corrente (PD semplice) ===
    derr_poscur = (pos_err - err_poscur_prev) / dt;
    err_poscur_prev = pos_err;

    //=== Anti-windup ===
    if (fabs(out) > 2.26f && (pos_err * out) >= 0.0f) {
        pos_err = 0.0f;
    }

    i_ref_poscur = kp_pos_cur * pos_err + kd_pos_cur * derr_poscur;
    //i_ref_poscur = controller_pos_cur->process(pos_err,hw->get_dt());
    out_poscur = i_ref_poscur+ theta_dotdot * J + theta_dot * B;  
    

    // === Controllo posizione → velocità → corrente ===

    // v_ref = pos_err*kp_pos;
    // v_meas = hw->get_d_theta(0);
    // v_err = v_ref - v_meas+ theta_dot;  // feedforward

    // // float dvel_err = (v_err - v_err_prev) / dt;
    // // float v_err_prev = v_err;

    // // === Anti-windup ===
    // if (fabs(out) > 4.06f && (v_err * out) >= 0.0f) {
    //     v_err = 0.0f;
    // }

    // // i_ref = 0.01*v_err + dvel_err*0.0001;
    // i_ref = controller_pos_vel_cur_velocity->process(v_err, hw->get_dt());

    //  // === Aggiorna stati ===
    // theta_past = reference;
    // theta_dot_past = theta_dot;
    // theta_dotdot_past = theta_dotdot;

    // // // === Uscita finale ===
    // out = i_ref+ theta_dotdot * J + theta_dot * B ; 

    return out_poscur;
}


//     Errore posizione
//     err = reference - theta;
//     // err = alpha * err_raw + (1 - alpha) * errPast;

//     // // Parte integrativa
//     // ierr += err * dt;

//     // // Parte derivativa
//     // derr = (err - errPast) / dt;

//     // // Controllore PID
//     // out = kp * err + ki * ierr + kd * derr;

//     // // Salva errore per il prossimo ciclo
//     // errPast = err;

