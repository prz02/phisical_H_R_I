#ifndef FORECAST_REFGEN_HPP
#define FORECAST_REFGEN_HPP

#include <vector>
#include <forecast/IHardware.hpp>

namespace forecast {
    class ReferenceGenerator {
    public:
        ReferenceGenerator() = default;

        virtual ~ReferenceGenerator() = default;

        virtual std::vector<float> process(const IHardware* hw) = 0;
    };   
}

#endif