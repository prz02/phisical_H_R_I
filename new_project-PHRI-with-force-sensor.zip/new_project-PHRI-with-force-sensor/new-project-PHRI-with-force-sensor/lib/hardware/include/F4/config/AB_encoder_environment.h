#ifndef CONFIG_ABENCODER_MOTOR_H
#define CONFIG_ABENCODER_MOTOR_H

namespace motorEncoder {

    constexpr float CPR = 5000.0f * 4.0f;
    constexpr float GEAR_RATIO = 1.0f;

}

#endif
