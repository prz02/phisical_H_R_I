#ifndef CONFIG_ESCON_MOTOR_H
#define CONFIG_ESCON_MOTOR_H

namespace motorControl {

    constexpr PinName MOTOR_ENABLE_PIN = PC_10;
    constexpr PinName MOTOR_CURRENT_FEEDBACK_PIN = A0;
    constexpr PinName MOTOR_ANALOG_PIN = A2;

    constexpr float MAX_CURR = 5.0f;
    constexpr float KT = 0.1964;
    constexpr float JM = 0.0133f;

}

#endif // CONFIG_ENV_ESCON_MOTOR_H