#ifndef CONFIG_SPRING_H
#define CONFIG_SPRING_H

#define KS 45

#endif // CONFIG_SPRING_H