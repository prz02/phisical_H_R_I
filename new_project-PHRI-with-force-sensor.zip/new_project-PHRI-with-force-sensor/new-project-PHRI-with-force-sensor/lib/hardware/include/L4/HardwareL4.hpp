#ifndef FORECAST_RPC_HARDWARE_HPP
#define FORECAST_RPC_HARDWARE_HPP

#ifdef TARGET_STM32L4

#include <hw/DigitalEncoder/DigitalEncoderAB.h>
#include <hw/Motor/EsconMotor.h>
#include <hw/Periphericals/Analog_input.h>
#include <mbed.h>
#include <utility/filters/AnalogFilter.hpp>
#include <utility/math.hpp>

#include <forecast/IHardware.hpp>
#include <forecast/Status.hpp>

using namespace forecast;

namespace hardware {
class HardwareL4 : public IHardware {
   public:
    /**
     * @brief   Hardware constructor
     */
    HardwareL4(App& app) : IHardware(app) {
        // DEBUG_INFO("Hardware constructor called\n");

        logs["t"] = &current_time;

        logs["tauM"] = &tauM;
        logs["torqueSensor"] = &tauS;

        logs["thetaM"] = &thetaM;
        logs["dthetaM"] = &dthetaM;
        logs["ddthetaM"] = &ddthetaM;
    }

    /**
     * @brief   Initialization of the Hardware
     */
    Status init();

    virtual inline size_t get_motor_num() const override { return 1; }

    virtual inline size_t get_tau_sensor_num() const override { return 2; }

    virtual inline size_t get_theta_sensor_num() const override { return 1; }

    virtual inline void set_tau_m(size_t index, float torque) override {
        if (index == 0) {
            control_motor->setTorque(torque);
            return;
        }
        app.send_error("unknown motor index in set_tau_m");
    }

    /**
     * @brief   Return the hw time t of the last update.
     *
     * @return  t
     */
    virtual inline float get_t() const override { return t; }
    /**
     * @brief   Return the hw dt used in the last update.
     *
     * @return  dt
     */
    virtual inline float get_dt() const override { return dt; }

    /**
     * @brief   Set the start time of the experiment.
     *
     * @param  time The start time of the experiment
     */
    inline void set_start_time(float time) override { start_t = time; }

    /**
     * @brief   Return the start time of the experiment.
     *
     * @return  start_t
     */
    virtual inline float get_start_time() const override { return start_t; }

    /**
     * @brief   Return the hw time t from the start of the experiment.
     *
     * @return  curr_t
     */
    virtual inline float get_current_time() const override {
        return t - start_t;
    }

    /**std::make_unique<control::Control>()
     * @brief   Return the torque applied by the motor (current feedback)
     *
     * @return  motorTorqueFeedback
     */
    virtual inline float get_tau_m(size_t motor_idx) const override {
        switch (motor_idx) {
            case 0:
                return tauM;
            default:
                app.send_error("invalid motor inde in get_tau_m");
                return 0.f;
        }
    }
    virtual inline float get_d_tau_m(size_t motor_idx) const override {
        switch (motor_idx) {
            default:
                app.send_error("invalid motor inde in get_d_tau_m");
                return 0.f;
        }
    }
    virtual inline float get_dd_tau_m(size_t motor_idx) const override {
        switch (motor_idx) {
            default:
                app.send_error("invalid motor inde in get_dd_tau_m");
                return 0.f;
        }
    }

    /**
     * @brief   Return the torque measured by the force sensor
     *
     * @return  tau_s
     */
    virtual inline float get_tau_s(size_t sensor_idx) const {
        switch (sensor_idx) {
            case 0:
                return tauS;
            default:
                app.send_error("invalid sensor index in get_tau_s");
                return 0.f;
        }
    }
    virtual inline float get_d_tau_s(size_t sensor_idx) const {
        switch (sensor_idx) {
            default:
                app.send_error("invalid sensor index in get_d_tau_s");
                return 0.f;
        }
    }
    virtual inline float get_dd_tau_s(size_t sensor_idx) const {
        switch (sensor_idx) {
            default:
                app.send_error("invalid sensor index in get_dd_tau_s");
                return 0.f;
        }
    }

    /**
     * @brief   Return the angle radius measured by the encoder of the motor.
     *
     * @return  thetaM
     */
    virtual inline float get_theta(size_t sensor_idx) const {
        switch (sensor_idx) {
            case 0:  // motor
                return thetaM;
            default:
                app.send_error("invalid sensor index in get_theta");
                return 0.f;
        }
    }
    virtual inline float get_d_theta(size_t sensor_idx) const {
        switch (sensor_idx) {
            case 0:  // motor
                return dthetaM;
            default:
                app.send_error("invalid sensor index in get_theta");
                return 0.f;
        }
    }
    virtual inline float get_dd_theta(size_t sensor_idx) const {
        switch (sensor_idx) {
            case 0:  // motor
                return ddthetaM;
            default:
                app.send_error("invalid sensor index in get_theta");
                return 0.f;
        }
    }

    virtual inline float get_output() const override { return output; }
    virtual inline float get_d_output() const override { return doutput; }
    virtual inline float get_dd_output() const override { return ddoutput; }

    virtual inline void safety_on() { control_motor->setEnable(false); }

    virtual inline void safety_off() { control_motor->setEnable(true); }

    /**
     * @brief   Update the Hardware by reading the value from the physical hw
     *
     * @param   Torque that has to be given to the motor for actuating the
     * control Torque that has to be given to the environment for the simulation
     *
     * @param   dt is the delta time in seconds to use for the
     * calculations for controls
     */
    // void update(float controlTorque, float envTorque, float dt);
    virtual void update(float dt) override;

    virtual void home() override;

   protected:
    bool motorEncoderInit();  /// < Initialize the motor encoder

    bool motorControlInit();  ///< Initialize the motor

    bool sensorInit();  ///< Initialize the torque sensor

    DigitalEncoderAB* encoder_motor = nullptr;  ///< Motor encoder
    EsconMotor* control_motor = nullptr;        ///< Motor used for the control
    Analog_Input* torque_sensor = nullptr;      ///< Torque sensor

    utility::AnalogFilter* lowpass_filter;

    float t, dt, current_time;
    float start_t;

    float tauM = 0.0;
    float torqueSensorOffset = 0.0;
    float tauS = 0.0;
    
    float thetaM = 0.0;
    float thetaOffset = 0.0;
    float dthetaM = 0.0;
    float ddthetaM = 0.0;
    float prev_thetaM = 0.0;
    float prev_dthetaM = 0.0;

    float output = 0.0;
    float doutput = 0.0;
    float ddoutput = 0.0;
};
}  // namespace hardware

#endif
#endif