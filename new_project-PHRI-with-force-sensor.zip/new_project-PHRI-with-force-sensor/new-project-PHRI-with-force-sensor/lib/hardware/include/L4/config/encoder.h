#ifndef CONFIG_L4ENCODER_H
#define CONFIG_L4ENCODER_H

namespace motorEncoder
{
    /**************** GROUP A and B *****************/
    constexpr float CPR = 4096.0f;
    constexpr float GEAR_RATIO = 103.0f;

    /******************** GROUP C *******************/
    // constexpr float CPR = 4096.0f * 4.0f;
    // constexpr float GEAR_RATIO = 1.0f;

    /******************** GROUP D *******************/
    // constexpr float CPR = 2048.0f * 4.0f;
    // constexpr float GEAR_RATIO = 89.0f;

    /******************** GROUP E *******************/
    // constexpr float CPR = 2048.0f * 4.0f;
    // constexpr float GEAR_RATIO = 43.0f;

}

#endif
