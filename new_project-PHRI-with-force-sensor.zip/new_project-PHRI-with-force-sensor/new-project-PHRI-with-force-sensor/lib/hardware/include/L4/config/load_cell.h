#ifndef LOADCELL_H
#define LOADCELL_H

namespace loadcell
{

    constexpr PinName PIN = A0;
    constexpr float OFFSET = 0.0f;
    constexpr int BUFFER_SIZE = 128;
    constexpr float VOLTAGE2KG = 0.272f / 0.134f;
    constexpr float LENGTH = 0.33f;

}

#endif
