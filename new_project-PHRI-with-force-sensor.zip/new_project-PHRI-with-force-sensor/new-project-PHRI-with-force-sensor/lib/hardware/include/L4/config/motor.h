#ifndef L4_MOTOR_H
#define L4_MOTOR_H

namespace motorControl {

    constexpr PinName MOTOR_ENABLE_PIN = D12;
    constexpr PinName MOTOR_CURRENT_FEEDBACK_PIN = A3;
    constexpr PinName MOTOR_ANALOG_PIN = A4;

    /**************** GROUP A and B *****************/
    constexpr float MAX_CURR = 2.26f;
    constexpr float KT = 1.504f;
    constexpr float JM = 0.0104f;
    constexpr float DM = 0.0068f;

    /******************** GROUP C *******************/
    // constexpr float MAX_CURR = 4.06f;
    // constexpr float KT = 0.231f;
    // constexpr float JM = 0.000506f;
    // constexpr float DM = 0.00001f;

    /******************** GROUP D *******************/
    // constexpr float MAX_CURR = 3.33f;
    // constexpr float KT = 2.65f;
    // constexpr float JM = 0.054f;
    // constexpr float DM = 0.17f;

    /******************** GROUP E *******************/
    // constexpr float MAX_CURR = 4.29f;
    // constexpr float KT = 1.26f;
    // constexpr float JM = 0.024f;
    // constexpr float DM = 0.1f;

}  // namespace motorControl

#endif  // CONFIG_ENV_ESCON_MOTOR_H
