#ifdef TARGET_STM32F4

#include <F4/HardwareF4.hpp>


using namespace forecast;

Status hardware::HardwareF4::init() {

  wait_ms(1000);

  if (not motorEncoderInit())
    return Status::MOTOR_ENCODER_INIT_ERR;

  if (not motorControlInit())
    return Status::CONTROL_MOTOR_INIT_ERR;
  control_motor->setTorque(0.f);

  motorEnvironmentInit();

  if (not torqueSensorInit())
    return Status::TORQUE_SENSOR_INIT_ERR;

  return Status::NO_ERROR;
}

bool hardware::HardwareF4::motorEncoderInit() {
  encoder_motor =
      new DigitalEncoderAB(motorEncoder::CPR, motorEncoder::GEAR_RATIO);

  /* Set the encoder timer */
  encoder_motor->setTIM1(); // read position
  encoder_motor->setTIM3(); // read velocity

  return true;
}

bool hardware::HardwareF4::motorControlInit() {
  MotorConfiguration conf;
  conf.enable = motorControl::MOTOR_ENABLE_PIN;
  conf.currFeedback = motorControl::MOTOR_CURRENT_FEEDBACK_PIN;
  conf.analog = motorControl::MOTOR_ANALOG_PIN;

  /* Control motor */
  control_motor = new EsconMotor(conf, motorControl::KT, motorControl::JM,
                                 motorControl::MAX_CURR);

  return control_motor != nullptr;
}

bool hardware::HardwareF4::motorEnvironmentInit() {
  MotorConfiguration conf;
  conf.enable = envMotor::MOTOR_ENABLE_PIN;
  conf.currFeedback = envMotor::MOTOR_CURRENT_FEEDBACK_PIN;
  conf.analog = envMotor::MOTOR_ANALOG_PIN;

  /* Environment motor */
  env_motor =
      new EsconMotor(conf, envMotor::KT, envMotor::JM, envMotor::MAX_CURR);

  return env_motor != nullptr;
}

bool hardware::HardwareF4::torqueSensorInit() {
  torque_sensor =
      new AnalogInput(A4, ADC_PCLK2, ADC_Right, ADC_15s, ADC_12b,
                      ADC_Continuous, ADC_Dma, TORQUE_SENSOR_BUFFER_SIZE);
  // strain =
  //   new AnalogInput(PA_1, ADC_PCLK2, ADC_Right, ADC_15s, ADC_12b,
  //                   ADC_Continuous, ADC_Dma, TORQUE_SENSOR_BUFFER_SIZE);

  // strain->enable();
  torque_sensor->enable();
  tauSensorOffset = torque_sensor->read_average_float() * 3.3f;
  // strain_offset = strain->read_average_float() * 3.3f;

  return true;
}

// void hardware::HardwareF4::update(float controlTorque,
//                                 float envTorque,
//                                 float dt) {
void hardware::HardwareF4::update(float dt) {
  /* Time update */
  this->dt = dt;
  t = us_ticker_read() / 1e6;
  current_time = get_current_time();

  /* Motor encoder update */
  /* Motor encoder is mounted in the opposite position wrt env encoder */
  thetaM = -encoder_motor->getAngleRad();
  // thetaM += 1;
  // dthetaM = (thetaM - prev_thetaM) / dt;
  dthetaM = -encoder_motor->getVelocityRad(dt);
  ddthetaM = (dthetaM - prev_dthetaM) / dt;
  prev_thetaM = thetaM;
  prev_dthetaM = dthetaM;

  /* Control motor update  (from Escon feedback) */
  tauM = control_motor->getTorqueFeedback();


  // /* Spring torque update */

  /* Control motor update  (from torque sensor) */
  // +10 -10 Volt
  // tauSensor = -((torque_sensor->read_average_float() * 3.3f) - 1.625f) *
  //             7.6075f * 1.418f;
  tauSensor = ((torque_sensor->read_average_float() * 3.3f) - tauSensorOffset);
  // tau_strain = ((strain->read_average_float() * 3.3f) - strain_offset);

}

void hardware::HardwareF4::home() {
  encoder_motor->reset(0);
  wait_ms(500);
}

#endif // TARGET_STM32F4
