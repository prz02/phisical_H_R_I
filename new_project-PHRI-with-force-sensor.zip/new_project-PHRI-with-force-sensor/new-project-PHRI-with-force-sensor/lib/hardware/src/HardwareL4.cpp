#ifdef TARGET_STM32L4

#include <L4/HardwareL4.hpp>
#include <utility/math.hpp>

#include <L4/config/encoder.h>
#include <L4/config/load_cell.h>
#include <L4/config/motor.h>

using namespace forecast;

forecast::Status hardware::HardwareL4::init() {
    wait_ms(1000);

    if (not motorEncoderInit())
        return Status::MOTOR_ENCODER_INIT_ERR;

    if (not motorControlInit())
        return Status::CONTROL_MOTOR_INIT_ERR;

    control_motor->setTorque(0.0f);

    if (not sensorInit())
        return Status::TORQUE_SENSOR_INIT_ERR;

    return Status::NO_ERROR;
}

bool hardware::HardwareL4::motorEncoderInit() {
    encoder_motor =
        new DigitalEncoderAB(motorEncoder::CPR, motorEncoder::GEAR_RATIO);
    encoder_motor->setLPTIM1();
    encoder_motor->setVelocityTIM15();

    return true;
}

bool hardware::HardwareL4::motorControlInit() {
    MotorConfiguration conf;
    conf.enable = motorControl::MOTOR_ENABLE_PIN;
    conf.currFeedback = motorControl::MOTOR_CURRENT_FEEDBACK_PIN;
    conf.analog = motorControl::MOTOR_ANALOG_PIN;

    /* Control motor */
    control_motor = new EsconMotor(conf, motorControl::KT, motorControl::JM,
                                   motorControl::MAX_CURR);

    return control_motor != nullptr;
}

bool hardware::HardwareL4::sensorInit() {
    torque_sensor = new Analog_Input(A1);

    control_motor->currFeedback.init(ADC_PCLK2, ADC_Right, ADC_12s5, ADC_12b,
                                     ADC_Continuous, ADC_Dma, 128);

    torque_sensor->init(ADC_PCLK2, ADC_Right, ADC_12s5, ADC_12b, ADC_Continuous,
                        ADC_Dma, 128);

    control_motor->currFeedback.enable();
    torque_sensor->enable();

    control_motor->currFeedback.read_average_float();

    constexpr uint8_t ITERATIONS = 200;
    for (uint8_t i = 0; i < ITERATIONS; ++i) {
        torqueSensorOffset += torque_sensor->read_average_float();
    }
    torqueSensorOffset /= ITERATIONS;

    return true;
}

void hardware::HardwareL4::update(float dt) {
    /* Time update */
    this->dt = dt;
    t = us_ticker_read() / 1e6;
    current_time = get_current_time();

    thetaM = encoder_motor->getAngleRad();
    dthetaM = (thetaM - prev_thetaM) / dt;
    ddthetaM = (dthetaM - prev_dthetaM) / dt;

    tauS = -(torque_sensor->read_average_float() - torqueSensorOffset) *
            3.3f * 2.16f * 9.81f * 0.04f;  // Nm

    prev_thetaM = thetaM;
    prev_dthetaM = dthetaM;

    tauM = control_motor->getTorqueFeedback();
}

void hardware::HardwareL4::home() {
    NVIC_SystemReset();
}

#endif