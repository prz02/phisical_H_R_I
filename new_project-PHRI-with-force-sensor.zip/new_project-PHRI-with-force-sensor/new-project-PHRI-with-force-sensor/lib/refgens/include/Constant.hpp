#ifndef CONSTANT_REF_GEN_HPP
#define CONSTANT_REF_GEN_HPP

#include <forecast/ReferenceGenerator.hpp>

namespace refgen
{
    class Constant : public forecast::ReferenceGenerator
    {
    private:
        std::vector<float> values;

    public:
        Constant(std::vector<float> v = {0.f});

        virtual std::vector<float> process(const forecast::IHardware *hw);
    };

    inline forecast::RefGenFactory::Builder make_constant_ref_gen_builder()
    {

        auto fn = [](std::vector<float> params) -> forecast::ReferenceGenerator *
        {
            if (params.empty())
                return nullptr;

            return new Constant({params[0]});
        };

        return {fn, {"Value"}};
    }
}

#endif
