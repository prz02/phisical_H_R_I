#ifndef RAMP_REF_GEN_HPP
#define RAMP_REF_GEN_HPP

#include <forecast/ReferenceGenerator.hpp>

namespace refgen
{
    class Ramp : public forecast::ReferenceGenerator
    {
    private:
        float slope;
        float start_time;
        float initial_output;
        float saturation;

    public:
        Ramp(float slope = 1.0f, float start_time = 0.0f, float initial_output = 0.0f, float saturation = 0.0f);
        virtual std::vector<float> process(const forecast::IHardware *hw);
    };

    inline forecast::RefGenFactory::Builder make_ramp_ref_gen_builder()
    {

        auto fn = [](std::vector<float> params) -> forecast::ReferenceGenerator *
        {
            if (params.size() < 4)
                return nullptr;
            return new Ramp(params[0], params[1], params[2], params[3]);
        };

        return {fn, {"Slope, Start time, Initial output", "Saturation"}};
    }
}

#endif // FORECAST_CONSTANT_REF_GEN_HPP