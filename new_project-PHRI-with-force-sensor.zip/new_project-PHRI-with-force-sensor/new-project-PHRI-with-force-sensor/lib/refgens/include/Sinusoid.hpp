#ifndef SINUSOID_REF_GEN_HPP
#define SINUSOID_REF_GEN_HPP

#include <forecast/ReferenceGenerator.hpp>

namespace refgen
{
    class Sinusoid : public forecast::ReferenceGenerator
    {
    private:
        float frequency; // given in rad/s
        float amplitude;
        float offset;

    public:
        Sinusoid(float frequency = 1.0f, float amplitude = 1.0f, float offset = 0.0f);

        virtual std::vector<float> process(const forecast::IHardware *hw);
    };

    inline forecast::RefGenFactory::Builder make_sinusoid_ref_gen_builder()
    {

        auto fn = [](std::vector<float> params) -> forecast::ReferenceGenerator *
        {
            if (params.size() < 3)
                return nullptr;

            return new Sinusoid(params[0], params[1], params[2]);
        };

        return {fn, {"Frequency, Amplitude, Offset"}};
    }
}

#endif
