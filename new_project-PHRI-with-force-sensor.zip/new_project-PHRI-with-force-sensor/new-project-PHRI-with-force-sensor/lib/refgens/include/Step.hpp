#ifndef STEP_REF_GEN_HPP
#define STEP_REF_GEN_HPP

#include <forecast/ReferenceGenerator.hpp>

namespace refgen
{
    class Step : public forecast::ReferenceGenerator
    {
    private:
        float amplitude;
        float step_time;

    public:
        Step(float amplitude = 1.0f, float step_time = 1.0f);

        virtual std::vector<float> process(const forecast::IHardware *hw);
    };

    inline forecast::RefGenFactory::Builder make_step_ref_gen_builder()
    {

        auto fn = [](std::vector<float> params) -> forecast::ReferenceGenerator *
        {
            if (params.size() < 2)
                return nullptr;

            return new Step(params[0], params[1]);
        };

        return {fn, {"Amplitude, Step time"}};
    }
}

#endif
