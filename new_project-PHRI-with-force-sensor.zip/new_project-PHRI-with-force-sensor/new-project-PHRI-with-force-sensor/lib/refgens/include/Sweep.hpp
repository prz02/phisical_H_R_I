#ifndef SWEEP_REF_GEN_HPP
#define SWEEP_REF_GEN_HPP

#include <forecast/ReferenceGenerator.hpp>

namespace refgen
{
    class Sweep : public forecast::ReferenceGenerator
    {
    private:
        float max_frequency;    // given in rad/s
        float duration;         // actually target time
        float amplitude;
        float offset;

    public:
        Sweep(float max_frequency, float duration, float amplitude, float offset);
        virtual std::vector<float> process(const forecast::IHardware *hw);
    };

    inline forecast::RefGenFactory::Builder make_sweep_ref_gen_builder()
    {
        auto fn = [](std::vector<float> params) -> forecast::ReferenceGenerator *
        {
            if (params.size() < 4)
                return nullptr;

            return new Sweep(params[0], params[1], params[2], params[3]);
        };
        return {fn, {"Max frequency, Target time, Amplitude, Offset"}};
    }
}

#endif
