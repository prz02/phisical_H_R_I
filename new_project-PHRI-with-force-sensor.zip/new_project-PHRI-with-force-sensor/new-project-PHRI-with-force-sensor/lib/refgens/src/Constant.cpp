#include <Constant.hpp>

using namespace refgen;

Constant::Constant(std::vector<float> v) : values(std::move(v))
{
    // ntd;
}

std::vector<float> Constant::process(const forecast::IHardware *hw)
{
    return values;
}
