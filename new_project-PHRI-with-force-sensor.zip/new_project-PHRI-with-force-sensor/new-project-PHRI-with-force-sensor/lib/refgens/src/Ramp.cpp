#include <Ramp.hpp>

using namespace refgen;

Ramp::Ramp(float slope, float start_time, float initial_output, float saturation)
    : slope(slope), start_time(start_time), initial_output(initial_output), saturation(saturation)
{
    // ntd;
}

std::vector<float> Ramp::process(const forecast::IHardware *hw)
{
    float time = hw->get_current_time();
    float output = (time > start_time) ? initial_output + slope * time : initial_output;
    output = fabs(output) > fabs(saturation) ? saturation : output;
    return {output};
}
