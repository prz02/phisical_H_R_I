#include <Sinusoid.hpp>

using namespace refgen;

Sinusoid::Sinusoid(float frequency, float amplitude, float offset) : frequency(frequency), amplitude(amplitude), offset(offset)
{
    // ntd;
}

std::vector<float> Sinusoid::process(const forecast::IHardware *hw)
{
    float output = amplitude * sin(2 * M_PI * frequency * hw->get_current_time()) + offset;
    return {output};
}
