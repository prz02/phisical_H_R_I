#include <Step.hpp>
#include <utility/math.hpp>

using namespace refgen;

Step::Step(float amplitude, float step_time) : amplitude(amplitude), step_time(step_time) {
    // ntd;
}

std::vector<float> Step::process(const forecast::IHardware* hw) {
    float time = hw->get_current_time();
    float output = (time > step_time)? amplitude : 0.0f;
    return {output};
}
