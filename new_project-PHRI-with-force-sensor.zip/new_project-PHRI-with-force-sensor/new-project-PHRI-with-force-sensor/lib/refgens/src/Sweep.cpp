#include <Sweep.hpp>

using namespace refgen;

Sweep::Sweep(float max_freq, float duration, float amplitude, float offset) : max_frequency(max_freq), duration(duration), amplitude(amplitude), offset(offset)
{
    // ntd;
}

std::vector<float> Sweep::process(const forecast::IHardware *hw)
{
    float time = hw->get_current_time();
    float frequency = max_frequency / (2 * duration) * time;
    float output = amplitude * sin(2 * M_PI * time * frequency) + offset;
    return {output, frequency};
}
