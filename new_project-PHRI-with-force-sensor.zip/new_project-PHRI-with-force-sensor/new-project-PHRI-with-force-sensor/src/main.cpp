#include <mbed.h>
#include <forecast/App.hpp>

#include <L4/HardwareL4.hpp>

#include <PositionPID.hpp>
#include <Force_controller.hpp>
#include <ImpedanceControl.hpp>
#include <ImplicitImpedance.hpp>
#include <AdmittanceControl.hpp>


#include <Step.hpp>
#include <Sinusoid.hpp>
#include <Ramp.hpp>
#include <Sweep.hpp>

int main() {

  forecast::App app;

  hardware::HardwareL4 hw(app);
  hw.init();
  app.set_hw(&hw);

  //app.get_controller_factory().add("PositionPID", controllers::make_position_PID_builder());
  //app.get_controller_factory().add("Force_controller", controllers::make_force_controller_builder());
  //app.get_controller_factory().add("ImplicitImpedance", controllers::make_imp_impedence_controller_builder());
  app.get_controller_factory().add("ImpedanceControl", controllers::make_impedence_controller_builder());
  //app.get_controller_factory().add("AdmittanceControl", controllers::make_admittance_controller_builder());



  app.get_ref_gen_factory().add("Step", refgen::make_step_ref_gen_builder());
  app.get_ref_gen_factory().add("Sinusoid", refgen::make_sinusoid_ref_gen_builder());
  app.get_ref_gen_factory().add("Ramp", refgen::make_ramp_ref_gen_builder());
  app.get_ref_gen_factory().add("Sweep", refgen::make_sweep_ref_gen_builder());

  app.run();

  return 0;
}
