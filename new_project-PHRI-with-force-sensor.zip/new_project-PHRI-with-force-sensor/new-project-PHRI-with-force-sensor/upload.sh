docker run --rm --mount type=bind,source="$(pwd)",target=/workspace -it  platformio pio run -e L4
cp .pio/build/L4/firmware.bin /media/$USER/NODE_L432KC/